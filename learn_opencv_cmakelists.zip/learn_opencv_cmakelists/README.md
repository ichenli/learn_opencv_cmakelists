consturct program by cmakelists.txt using extern lib of OPENCV
