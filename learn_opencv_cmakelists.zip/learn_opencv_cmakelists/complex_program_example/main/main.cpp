#include<iostream>
#include <opencv2/core/core.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include "../include/hello.h"

int main(){
    cv::Mat img;
    std::cout<< "main func"<<std::endl;
    sayhello();
    return 0;
}
