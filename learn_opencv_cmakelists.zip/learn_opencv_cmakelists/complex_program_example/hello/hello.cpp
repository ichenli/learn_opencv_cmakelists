#include<iostream>

void sayhello(){
    std::cout<< "hello world"<<std::endl;
}
